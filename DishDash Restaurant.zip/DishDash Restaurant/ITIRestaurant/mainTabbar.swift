//
//  mainTabbar.swift
//  ITIRestaurant
//
//  Created by MacBook Pro on 16/09/2024.
//

import UIKit

class mainTabbar: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    
}

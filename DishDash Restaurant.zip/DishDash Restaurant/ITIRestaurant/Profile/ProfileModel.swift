//
//  Profile.swift
//  ITIRestaurant
//
//  Created by MacBook Pro on 20/09/2024.
//


struct Profile{
    var name: String
    let Phone: String
    let Email: String
    let password: String
}
